# a7cc2a4 / 1a21b0c composition acceptance

Status: `COMPOSED_ARCHIVE_PIN_VERIFY_GREEN_WITH_ONE_UNCHANGED_BASE_REGISTRY_RED`.

This tree is a temporary acceptance composition, not a delivery commit and not a self-review. Primary owns integration, review, and delivery.

## Identity

- Base: `61e8c534b5295fb0f60a6634ad3cf99d99f12a4c`
- Branch: `codex/a7cc2a4-transition-acceptance-20261004`
- Pin patch: `db284075ba67afbec68d62dbf615091dd7f9fa6b9a76207c64b1e8b59117ca09`
- Transition patch: `fe5e8ecd6fe6e0c92738507935c32d5c5bf4957e7be10e18d51b0833bd24cdcb`
- Composed migration.rs: `3b29d6d84a343d01d17ed9fd705b9078e3fe67713990bbcf653a4d0553a7a6cf`
- producer.rs: `96a9de39e7d9312ceca1a71cc38b807cc0e41cc0bc7b43a16926f778727f7f6e`
- reset_governance.rs: `89f1f36fa9b55134f66b431abaf3d1d1683f40bc496dcc70339f67f605b8485b`
- dagpipe.rs: `6761008bbe142f4db6089ce8494eca6d6176f14f8315896264c7a974ba387c08`
- migration manifest: `8a6ecdfcae0d23f4c07b800a16ff80d287e83905eeeb3dcdc7a006036755e626`
- graph manifest: `aa00bcc953a8716398fa592712fdb49450f36de1cf9d8dfc6cae4038bf0136cc`
- Retained tested binary: `docs/evidence/a7cc2a4-transition-acceptance-20261004/retained/appsdk-composed-acceptance`
- Retained binary SHA-256: `3466d44ee61d8bdd9dbe7c60f33c2badd762b257a20c8232135d1c666f6bea72`

## Result

- Both patches passed `git apply --check` and applied cleanly to the clean base; transition's `migration.rs` hunk applied at offset 37 after the pin hunk, with disjoint content.
- `cargo build --manifest-path rust/Cargo.toml --bin appsdk`: exit 0.
- `cargo fmt --manifest-path rust/Cargo.toml -- --check`: exit 0.
- `appsdk dagpipe validate` from outside source cwd: exit 0; embedded and on-disk registry IDs both exactly the same 10 entries, including `appsdk-sdk-pin-history`.
- `dagpipe graph validate docs/dagpipe/sdk-pin-history.graph.json`: exit 0, `valid DAG: appsdk-sdk-pin-history@0.1.0 (6 nodes, 5 edges, 6 waves)`.
- `appsdk verify-sdk-source-registry .`: exit 1 on unchanged base-owned `collab/src/identity.rs:1826>1500`; this is independent of the two composed patches and is recorded as an external registry dependency. `git hash-object`/comparison shows the file is unchanged from `origin/main` at `61e8c534...`.
- First archive replay: `appsdk pin-lock FULL_ARCHIVE_ROOT --binary BUILT_BINARY` exit 0; same-binary ordinary `appsdk verify FULL_ARCHIVE_ROOT` exit 0.
- Reentry replay: second `pin-lock` exit 0; second ordinary `verify` exit 0; post-reentry full tree fingerprint equals the first post-`pin-lock` state.
- Historical record, four historical snapshots, four live maps, and module registry are byte-identical before and after pin.
- Current-step record source/target digests equal the four live map digests; the root transition files equal the exact current runtime canonical `ae910c4426c8bccc22c9e2256e8ca9842eb39c2caa783428afec5c9a2d44c5d5`.
- Archive remained hash-identical at `2d91c66612c307e2ba76ceba188ca613e557840d69b9ef1568bb33825e68db50`.

## Non-claims

- No review PASS, commit, merge, push, install, daemon restart, OTA, memory write, or Teams admission.
- The source-registry red is not repaired here and must be handled by the existing SDK registry/split owner.
- This mixed tree must not be delivered; primary will copy acceptance evidence into each distinct source unit before architecture review.

## Evidence map

- `00-baseline-identities.txt`, `01-apply-pin.*`, `02-apply-transition.*`, `03-composed-identities.txt`
- `logs/component-proof.txt` and `logs/component-*-source-hashes.txt`
- `logs/cargo-build.*`, `logs/cargo-fmt.*`, `logs/static-summary.txt`, `logs/dagpipe-validate.*`
- `logs/extract-archive.*`, `logs/fixture-before-snapshot.txt`, `logs/before-after-identities.txt`
- `logs/pin-lock.*`, `logs/verify.*`, `logs/pin-lock-reentry.*`, `logs/verify-reentry.*`
- `logs/current-step-live-agreement.tsv`, `logs/post-pin-invariants.txt`, `logs/reentry-invariants.txt`, `logs/historical-record-summary.txt`
- `logs/retained-binary.sha256`, `logs/retained-binary.version`
