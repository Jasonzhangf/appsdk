# Provider live milestone receipt

- Issue: `c5708f3`
- Candidate commit: `f9e90dbd3e721abed38cafb482f240de6e004137`
- Base commit: `f9e90dbd3e721abed38cafb482f240de6e004137`
- Candidate tree: clean worktree `codex/c5708f3-provider-live-milestone-20260912`
- Scope: explicit primary/backup provider dispatch, Agent/Relay configuration apply and readback, restart persistence
- Non-scope: automatic failover, inferred model IDs, public deployment, NAT-to-NAT/direct transport
- Source validation identity: `source-validation.log` records the candidate source SHA, Node `v22.22.2`, pnpm `10.31.0`, OpenCode `1.18.23`, syntax checks and `git diff --check`.

The original command output is retained beside this receipt. The executable
harnesses are `live-harness.mjs` and `opencode-harness.mjs`; their SHA-256 values
are in `harness-sha256.txt`. They accept `GOAICHAT_TOKEN` through the environment
and never read or write a credential file. The exact Agent/Relay command requests,
responses, projections, persisted revisions and restart readback are in
`agent-relay-harness.log`; the managed OpenCode request/response summaries are in
`opencode-harness.log`; the raw RCC request/status/body probes are in
`rcc-probes.log`.

## Discovery and explicit dispatch

RCC `GET http://127.0.0.1:4444/v1/models` returned HTTP 200 with empty `data` and
`models` arrays. The configured manual model remained `rcc-4444/gpt-5.5`.

Direct RCC dispatch used `POST /v1/chat/completions` with `model=gpt-5.5` and
`stream=false`; it returned HTTP 200, `finish_reason=stop`, and the exact marker
`teams-rcc-explicit-model`. The upstream response field `model=glm-5.3` was retained
as provider output and was not used as Teams configuration truth.

The credentialed GoAIChat probe returned 18 discovered entries, including the
explicitly configured backup `goaichat-openai/qwen3.8-max`. The Agent-side merged
catalog also contained 18 entries after deduplication. The raw credentialed probe is
retained in `rcc-probes.log`.

## Agent and Relay apply/readback

The isolated live harness started a real TLS Relay and a real Agent process from this
candidate. The Agent received both provider instances and the following bindings:

```text
primary: rcc-4444/gpt-5.5
backup:  goaichat-openai/qwen3.8-max
```

Remote Console commands over Relay produced (the `requests` and `projections`
objects are retained in `agent-relay-harness.log`):

```text
config.refreshModels(rcc-4444, expectedRevision=3) -> ok
config.refreshModels(goaichat-openai, expectedRevision=4) -> ok
config.apply -> ok
acceptedRevision=5
effectiveRevision=5
```

The persisted Agent config contained `acceptedRevision=5` and
`effectiveRevision=5`. After stopping and starting the Agent runtime again in the
harness, the Relay projection read the same `acceptedRevision=5` and
`effectiveRevision=5`. This is runtime stop/start persistence evidence; an OS-level
daemon restart remains a separate deployment gate.

An empty RCC discovery result therefore did not block explicit manual model use and
did not trigger backup selection. The same log records the persisted config summary
and the post-restart projection, so the restart claim does not rely on the in-memory
pre-stop projection.

## Real OpenCode provider replay

OpenCode `1.18.23` was started through the managed OpenCode owner with the same
primary and backup targets. Each target was selected explicitly in a real Session
message request. The sanitized request target, HTTP status, response marker and
response-body prefix are retained in `opencode-harness.log`:

```text
rcc-4444/gpt-5.5          -> HTTP 200, assistant=teams-rcc-open-code
goaichat-openai/qwen3.8-max -> HTTP 200, assistant=teams-goaichat-open-code
```

No response `model` field was used to rewrite configuration. No automatic failover
was exercised or claimed.

## Source verification

```text
pnpm exec vitest run config/runtime-config.spec.ts config/provider-model-client.spec.ts \
  opencode-adapter/tests/managed-config.spec.ts runtime/managed-opencode-session.spec.ts
4 files passed; 34 tests passed
```

The complete test output is retained in `focused-tests.log`. AppSDK contract
verification is retained in `appsdk-verify.log`.

The root source tree was unchanged by the live probes. Credentials were read through
the configured reference only and are not stored in this receipt.

## Remaining boundary

This receipt closes the provider live milestone candidate. The parent issue remains
open until the primary integration owner reconciles this receipt with the remaining
MVP gates (public Relay deployment, real NAT egress, daemon Work replay, Console
offline Work and OS-level daemon restart) and records an independent milestone review.
