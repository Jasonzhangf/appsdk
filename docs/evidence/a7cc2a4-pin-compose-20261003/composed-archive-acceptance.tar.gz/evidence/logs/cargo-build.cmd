started=2026-10-04T01:53:46Z
command=CARGO_TARGET_DIR=/Volumes/Intel/playground/appsdk/a7cc2a4-transition-acceptance-20261004/.tmp/cargo-target cargo build --manifest-path rust/Cargo.toml --bin appsdk
