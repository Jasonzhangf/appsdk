# 3c437d7 coder2new cross-host Agent Work replay

- Candidate: `origin/main@cf62442c74c22c387e7058d99fb397b34ca9b91a`
- Delivery unit: `3c437d7`; related Console-offline boundary: `9b10ed3`.
- Worktree: `playground/3c437d7-coder2-m2m-20260910`.
- Relay: Claw `wss://claw.codewhisper.cc:9443`; provider ran on Claw (`159.75.134.56`), consumer ran in a one-shot `node:22-alpine` Docker container on coder2new (`154.40.58.131`, hostname `ser162766042809`) with host networking.
- Artifact hashes, checked on both hosts:
  - `runtime/agent-process.js` = `730234b93f9dd0327cb259ead9f7eef208e166a0b98c8195fb53266fa03f61d8`
  - `runtime/agent-work-client.js` = `3a15a9e4714622844d7b67b80694efb99513c526b953e95b7a5f321ba62c18f3`
- Provider `claw-test-b` admitted at generation `27`; consumer `claw-test-a` admitted at generation `23`.
- Consumer directory discovery found provider `claw-test-b`, capability `file-search`, version `1`, operation `search`.
- Work `coder2-cross-host-work-2`: proposal `accepted`; request `succeeded`; close `closed`.
- Provider durable ledger readback: both replay works are `closed`, both requests are `succeeded`, and both `search-slot` allocations are `released`.
- No Console process participated. Provider capability was executed by `/usr/bin/rg` against an isolated replay root.
- Resource check before cleanup: no coder2new replay container remained; provider listener was only the owned loopback lease `127.0.0.1:48083`.

## Validation

- Candidate build input: `pnpm build:runtime` at `cf62442`; the two artifact hashes above were checked locally, on Claw, and on coder2new.
- Replay entrypoint: `node /replay/consumer.mjs` inside `node:22-alpine`; the process returned `status=passed` with the target, proposal, request, and close states recorded above.
- Provider ledger readback: `node` JSON projection of `provider-data2/work.json` on Claw; both Work records and both resource allocations were checked after the replay.
- Cleanup checks: exact-PID stop, `systemctl is-active/is-enabled agentteams-relay.service`, `ss` listener checks, `docker ps -a`, and temporary-directory existence checks.

### Integration candidate validation

- Integration worktree: `playground/3c437d7-coder2-m2m-integration-20260910`, based on `origin/main@cf62442c74c22c387e7058d99fb397b34ca9b91a`.
- First `pnpm test` attempt exited `1` because the fresh worktree had no dependencies (`tsdown: command not found`; `node_modules` missing). This failure is retained as setup evidence, not as a source regression.
- `pnpm install --frozen-lockfile` exited `0`; no lockfile or source path changed.
- Second `pnpm test` exited `0`: `70` files / `397` tests passed. The exact output was captured in `/tmp/agentteams-3c437d7-integration-test.log` during validation.
- `pnpm typecheck` exited `0`.
- `appsdk compile` exited `0`; artifact hash `sha256:7ea874ee3f7de08b5d3f1c7084ab9a61fe06b24fd77d086aa209f2ced6cd3789`.
- `appsdk verify` exited `0`: `{"ok":true,"project_id":"agentteams","stage":"contract_bound"}`.
- `git diff --check` exited `0`; the integration worktree was clean after validation.

## Exact review

- Reviewer: `consumer_work_exact_review` (independent agent), timestamp `2026-09-10T05:59:47-07:00`.
- Bound cwd: `/Volumes/extension/code/AgentTeams/playground/3c437d7-coder2-m2m-20260910`.
- Bound candidate/base: `cf62442c74c22c387e7058d99fb397b34ca9b91a`; `HEAD` and `origin/main` were equal at review time.
- Changed path: only this receipt; no source, configuration, artifact, or other worktree changes.
- Verdict: `PASS`; no P0/P1 finding. The reviewer confirmed that this receipt may be integrated alone and does not authorize unrelated delivery units.

## Boundary

This is real cross-host/public-relay Agent Work evidence for the current candidate. It does not prove dual-NAT traversal, direct transport, mobile/cellular access, production daemon installation, relay hostname DNS correctness for every client, or Console-offline V1 acceptance beyond the absence of a Console in this replay.

## Cleanup

- Provider PID was stopped by exact PID; Claw temporary directory was removed and no `48083` lease remained.
- The coder2new one-shot Docker container had already exited with `--rm`; its temporary directory was removed and no `48082` listener remained.
- Claw `agentteams-relay.service` remained `active` and `enabled`, with only its formal `0.0.0.0:9443` listener present.
- Owned candidate worktree `playground/3c437d7-coder2-m2m-20260910` and branch `codex/3c437d7-coder2-m2m-20260910` were removed after integration.
- Owned integration worktree `playground/3c437d7-coder2-m2m-integration-20260910` and branch `codex/3c437d7-coder2-m2m-integration-20260910` were removed after the remote push.
- External `/Users/fanzhang/.codex/worktrees/**` entries and all other branches/worktrees were left untouched.

## Final cleanup receipt

- Receipt ID: `cleanup-3c437d7-coder2-m2m-20260910`.
- Cleanup was performed only after review PASS, integration, mainline verification, and remote push.
- Remote main at cleanup start: `3538dff03aa0343fd6938fd6eb71248da2a593e3`.
- Claw and coder2new replay processes, container, temporary directories, and replay listeners were already absent; the formal Claw relay remained `active` and `enabled`.
- This cleanup worktree is the sole remaining owned resource for the receipt amendment and will be removed after its commit is pushed; no other resource is retained.
