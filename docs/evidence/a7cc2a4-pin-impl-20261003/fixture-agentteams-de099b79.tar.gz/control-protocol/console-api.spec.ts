import { describe, expect, it } from 'vitest'
import { parseConsoleCommand, parseConsoleWorkRelationProjection } from './console-api.ts'

describe('Console control ingress', () => {
  it('admits each frozen command without changing it', () => {
    const commands = [
      { kind: 'session.open', agentId: 'a', sessionId: 's' },
      { kind: 'permission.reply', agentId: 'a', sessionId: 's', permissionId: 'p', decision: 'reject' },
      { kind: 'notification.ack', agentId: 'a', notificationId: 'n' },
      { kind: 'config.refreshModels', agentId: 'a', expectedRevision: 0, providerId: 'p' },
      { kind: 'config.bindModel', agentId: 'a', expectedRevision: 1, providerId: 'p', modelId: 'm' },
      { kind: 'config.model.put', agentId: 'a', expectedRevision: 2, entry: {
        ref: { providerInstanceId: 'p', modelId: 'manual' }, origin: 'manual', base: { label: 'Manual', contextWindow: 4096 }, overrides: {},
      } },
      { kind: 'config.apply', agentId: 'a' },
      { kind: 'config.agent.select-backup', agentId: 'a', expectedRevision: 4, backup: { providerInstanceId: 'b', modelId: 'm' } },
      { kind: 'config.putProvider', agentId: 'a', expectedRevision: 0, provider: {
        id: 'p', label: 'P', protocol: 'openai-responses', apiBaseUrl: 'https://example.test/v1', enabled: true,
        auth: { kind: 'bearer', credentialRef: 'provider/p' },
      } },
    ]
    for (const command of commands) expect(parseConsoleCommand(command)).toEqual(command)
  })

  it('rejects unknown commands, fields and invalid identities or revisions', () => {
    for (const command of [
      null, [], { kind: 'session.delete', agentId: 'a' },
      { kind: 'session.open', agentId: 'a', sessionId: '' },
      { kind: 'config.apply', agentId: 'a', payload: { text: 'business' } },
      { kind: 'config.apply', agentId: 'a', metadata: {} },
      { kind: 'config.bindModel', agentId: 'a', expectedRevision: -1, providerId: 'p', modelId: 'm' },
      { kind: 'config.refreshModels', agentId: 'a', expectedRevision: 0.5, providerId: 'p' },
      { kind: 'config.agent.select-backup', agentId: 'a', expectedRevision: -1, backup: { providerInstanceId: 'b', modelId: 'm' } },
      { kind: 'config.agent.select-backup', agentId: 'a', expectedRevision: 1, backup: { providerInstanceId: 'b', modelId: 'm', credentialRef: 'secret' } },
      { kind: 'config.agent.select-backup', agentId: 'a', expectedRevision: 1, backup: { providerInstanceId: 'b' } },
      { kind: 'config.agent.selectBackup', agentId: 'a', expectedRevision: 1, backup: { providerInstanceId: 'b', modelId: 'm' } },
      { kind: 'permission.reply', agentId: 'a', sessionId: 's', permissionId: 'p', decision: 'yes' },
      { kind: 'config.model.put', agentId: 'a', expectedRevision: 0, entry: { ref: { providerInstanceId: 'p', modelId: 'm' }, origin: 'discovered', base: {}, overrides: {} } },
      { kind: 'config.model.put', agentId: 'a', expectedRevision: 0, entry: { ref: { providerInstanceId: 'p', modelId: 'm' }, origin: 'manual', base: { contextWindow: 0 }, overrides: {} } },
      { kind: 'config.model.put', agentId: 'a', expectedRevision: 0, entry: { ref: { providerInstanceId: 'p', modelId: 'm' }, origin: 'manual', base: {}, overrides: {}, extra: true } },
    ]) expect(() => parseConsoleCommand(command)).toThrow()
  })

  it('rejects inline credentials and surplus nested provider fields', () => {
    const provider = { id: 'p', label: 'P', protocol: 'openai-chat', apiBaseUrl: 'https://example.test/v1', enabled: true }
    for (const auth of [{ kind: 'none', token: 'secret' }, { kind: 'bearer', apiKey: 'secret' }, { kind: 'bearer', credentialRef: '' }]) {
      expect(() => parseConsoleCommand({ kind: 'config.putProvider', agentId: 'a', expectedRevision: 0, provider: { ...provider, auth } })).toThrow()
    }
    expect(() => parseConsoleCommand({ kind: 'config.putProvider', agentId: 'a', expectedRevision: 0, provider: { ...provider, auth: { kind: 'none' }, payload: {} } })).toThrow()
  })

  it('admits observe-only work and relation rows and rejects request payloads', () => {
    const works = [{ agentId: 'a', workId: 'w', consumerAgentId: 'c', providerAgentId: 'a', capabilityId: 'file-search', capabilityVersion: '1', policyRevision: 1, state: 'closed' }]
    const relations = [{ agentId: 'a', consumerAgentId: 'c', providerAgentId: 'a', capabilityId: 'file-search', capabilityVersion: '1', relationPermission: 'granted', workId: 'w' }]
    expect(parseConsoleWorkRelationProjection({ works, relations })).toEqual({ works, relations })
    expect(() => parseConsoleWorkRelationProjection({ works: [{ ...works[0], payload: { query: 'secret' } }], relations })).toThrow()
    expect(() => parseConsoleWorkRelationProjection({ works, relations: [{ ...relations[0], metadata: {} }] })).toThrow()
    expect(() => parseConsoleWorkRelationProjection({ agents: [], sessions: [], notifications: [], configs: [] })).toThrow()
  })
})
